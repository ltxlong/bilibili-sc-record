(function () {

    function handle_message(currentTabId) {
        chrome.tabs.sendMessage(currentTabId, { type: "popup_to_base", data: -1 }, (response) => {
            if (response) {
                let sc_blacklist_btn = document.getElementById('blacklist_btn');

                if (response.data == 1) {
                    sc_blacklist_btn.innerHTML = '当前直播房间已加入黑名单，点击移出黑名单';
                    sc_blacklist_btn.setAttribute('data-blacklist', 1);
                } else if (response.data == 2) {
                    sc_blacklist_btn.innerHTML = '点击将当前直播房间加入黑名单';
                    sc_blacklist_btn.setAttribute('data-blacklist', 2);
                } else {
                    sc_blacklist_btn.innerHTML = '点击将当前直播房间加入黑名单';
                    sc_blacklist_btn.setAttribute('data-blacklist', 0);
                }

                sc_blacklist_btn.addEventListener('click', function () {
                    let blacklist_val = sc_blacklist_btn.getAttribute('data-blacklist');
                    chrome.tabs.sendMessage(currentTabId, { type: "popup_to_base", data: blacklist_val });
                    window.close();
                });

                // 如果 URL 匹配，显示弹出菜单的内容
                document.body.style.display = 'block';
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs && tabs.length > 0) {
                let currentUrl = tabs[0].url;
                let currentTabId = tabs[0].id;
                let regex = /^https?:\/\/live\.bilibili\.com\/(\d{1,9}|blanc\/\d{1,9}).*$/;

                // 检查 URL 是否匹配正则表达式
                let match_result = currentUrl.match(regex);
                if (match_result) {
                    try {
                        handle_message(currentTabId);
                    } catch (error) {
                        throw(error);
                    }
                    
                } else {
                    // 如果 URL 不匹配，隐藏弹出菜单的内容
                    document.body.style.display = 'none';
                }
            }
        });
    });

})();