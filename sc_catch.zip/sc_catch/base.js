(async function () {

    let live_player_div = document.getElementById('live-player');
    if (!live_player_div) { return; }

    const injectScript = (file, node) => {
        const th = document.querySelector(node);
        const s = document.createElement('script');
        s.setAttribute('type', 'text/javascript');
        s.setAttribute('src', file);
        th.appendChild(s);
    };

    await injectScript(chrome.runtime.getURL('jquery3.7.1.min.js'), 'body');
    injectScript(chrome.runtime.getURL('html2canvas1.4.1.min.js'), 'body');
    injectScript(chrome.runtime.getURL('sc_catch.js'), 'body');

    console.log('start.......');

    let sc_room_id = window.location.pathname.split('/').pop();

    // 黑名单相关处理
    let sc_room_black_list_json = window.localStorage.getItem('live_sc_room_blacklist');
    let sc_room_black_list = [];
    let data_blacklist = 2; // 点击将当前直播房间加入黑名单
    if (sc_room_black_list_json === null || sc_room_black_list_json === 'null' || sc_room_black_list_json === '[]' || sc_room_black_list_json === '') {
        data_blacklist = 0; // 点击将当前直播房间加入黑名单
    } else {
        sc_room_black_list = JSON.parse(sc_room_black_list_json);
        if (sc_room_black_list.includes(sc_room_id)) {
            data_blacklist = 1; //点击将当前直播房间加入黑名单
        }
    }

    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.type === "popup_to_base") {
            if (request.data == 0) {
                window.localStorage.setItem('live_sc_room_blacklist', JSON.stringify([sc_room_id]));
                console.log('直播房间id：' + sc_room_id + ' 已加入黑名单！');
                alert("当前直播房间已加入黑名单，刷新页面生效！");
                window.top.location.reload();
            } else if (request.data == 1) {
                sc_room_black_list = sc_room_black_list.filter(item => item !== sc_room_id);
                window.localStorage.setItem('live_sc_room_blacklist', JSON.stringify(sc_room_black_list));
                console.log('直播房间id：' + sc_room_id + ' 已移出黑名单！');
                alert("当前直播房间已除出黑名单，刷新页面生效！");
                window.top.location.reload();
            } else if (request.data == 2) {
                sc_room_black_list.push(sc_room_id);
                window.localStorage.setItem('live_sc_room_blacklist', JSON.stringify(sc_room_black_list));
                console.log('直播房间id：' + sc_room_id + ' 已加入黑名单！');
                alert("当前直播房间已加入黑名单，刷新页面生效！");
                window.top.location.reload();
            } else {
                sendResponse({data: data_blacklist});
            }
        }
    });

})();